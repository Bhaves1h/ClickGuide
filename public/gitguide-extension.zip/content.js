// GitGuide Content Script - Injected into github.com
(function () {
  'use strict';

  if (window.__GITGUIDE_INJECTED__) return;
  window.__GITGUIDE_INJECTED__ = true;

  console.log('[GitGuide] Copilot active on github.com');

  const QUEST_DATABASE = {
    'create-repo': {
      title: 'Create My First Repository',
      steps: [
        {
          selector: 'a[href="/new"], a[href$="/new"], a.btn-primary[href*="new"], summary.Header-link[aria-label*="Create new"]',
          fallbackCoord: { x: window.innerWidth - 180, y: 32 },
          actionText: "Click 'New' repository",
          narrationEn: "Click the green 'New' button to create your first GitHub repository.",
          narrationHi: "अपना पहला GitHub रिपॉजिटरी बनाने के लिए हरे 'New' बटन पर क्लिक करें।"
        },
        {
          selector: 'input#repository_name, input[name="repository[name]"], input[aria-label*="Repository name"]',
          fallbackCoord: { x: 300, y: 240 },
          actionText: "Type repository name",
          narrationEn: "Enter a memorable name for your project, like 'my-first-repo'.",
          narrationHi: "अपने प्रोजेक्ट के लिए एक सरल नाम लिखें, जैसे 'my-first-repo'।"
        },
        {
          selector: 'button[type="submit"].btn-primary, button.btn-primary:has-text("Create repository")',
          fallbackCoord: { x: 260, y: 550 },
          actionText: "Click 'Create repository'",
          narrationEn: "Scroll down and click 'Create repository' to publish it!",
          narrationHi: "नीचे स्क्रॉल करें और 'Create repository' पर क्लिक करें!"
        }
      ]
    },
    'first-pr': {
      title: 'Open My First Pull Request',
      steps: [
        {
          selector: 'a[href*="/pulls"], #pull-requests-tab',
          fallbackCoord: { x: 240, y: 120 },
          actionText: "Go to Pull Requests",
          narrationEn: "Navigate to the 'Pull requests' tab of this repository.",
          narrationHi: "इस रिपॉजिटरी के 'Pull requests' टैब पर जाएं।"
        },
        {
          selector: 'a.btn-primary[href*="/compare"], a[href*="/compare"]',
          fallbackCoord: { x: window.innerWidth - 160, y: 150 },
          actionText: "Click 'New pull request'",
          narrationEn: "Click 'New pull request' or 'Compare & pull request' to select your branch.",
          narrationHi: "अपनी ब्रांच चुनने के लिए 'New pull request' पर क्लिक करें।"
        },
        {
          selector: 'button#create-pr-btn, button[type="submit"]',
          fallbackCoord: { x: window.innerWidth - 200, y: 400 },
          actionText: "Submit Pull Request",
          narrationEn: "Review your branch commits and click 'Create pull request' for maintainers to review.",
          narrationHi: "अपने बदलावों की जांच करें और मेंटेनर्स के रिव्यू के लिए 'Create pull request' दबाएं।"
        }
      ]
    }
  };

  let activeQuest = null;
  let currentStepIdx = 0;
  let activeLanguage = 'en';
  let speechEnabled = true;

  function speak(text, lang) {
    if (!speechEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
      u.rate = 0.95;
      window.speechSynthesis.speak(u);
    } catch (e) {}
  }

  function getOrCreateCursor() {
    let cursor = document.getElementById('gitguide-cursor');
    if (!cursor) {
      cursor = document.createElement('div');
      cursor.id = 'gitguide-cursor';
      cursor.innerHTML = `
        <div class="gitguide-cursor-wrapper">
          <div class="gitguide-cursor-pulse"></div>
          <svg class="gitguide-cursor-pointer" viewBox="0 0 24 24" fill="#ffffff">
            <path d="M4 2l16 12-7 1 4 7-3 1-4-7-6 5V2z"/>
          </svg>
          <div class="gitguide-action-pill" id="gitguide-cursor-pill">Click Here</div>
        </div>
      `;
      document.body.appendChild(cursor);
    }
    return cursor;
  }

  function getOrCreateNarrationBox() {
    let box = document.getElementById('gitguide-narration-box');
    if (!box) {
      box = document.createElement('div');
      box.id = 'gitguide-narration-box';
      box.innerHTML = `
        <div class="gitguide-box-header">
          <span>GitGuide Visual Copilot</span>
          <span id="gitguide-step-indicator">Step 1/3</span>
        </div>
        <div class="gitguide-box-title" id="gitguide-box-title">Quest Title</div>
        <div class="gitguide-box-text" id="gitguide-box-text">Narration instruction text</div>
        <div class="gitguide-box-footer">
          <div>
            <button class="gitguide-btn gitguide-btn-secondary" id="gitguide-lang-btn">EN / हिन्दी</button>
            <button class="gitguide-btn gitguide-btn-secondary" id="gitguide-close-btn">Exit</button>
          </div>
          <button class="gitguide-btn" id="gitguide-next-btn">Next Step &rarr;</button>
        </div>
      `;
      document.body.appendChild(box);

      box.querySelector('#gitguide-close-btn').addEventListener('click', stopQuest);
      box.querySelector('#gitguide-next-btn').addEventListener('click', nextStep);
      box.querySelector('#gitguide-lang-btn').addEventListener('click', () => {
        activeLanguage = activeLanguage === 'en' ? 'hi' : 'en';
        renderStep();
      });
    }
    return box;
  }

  function highlightElement(el) {
    document.querySelectorAll('.gitguide-target-highlight').forEach(e => e.classList.remove('gitguide-target-highlight'));
    if (el) {
      el.classList.add('gitguide-target-highlight');
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function renderStep() {
    if (!activeQuest || currentStepIdx >= activeQuest.steps.length) {
      stopQuest();
      return;
    }

    const step = activeQuest.steps[currentStepIdx];
    const cursor = getOrCreateCursor();
    const box = getOrCreateNarrationBox();

    // Find DOM element on GitHub page
    let targetEl = null;
    if (step.selector) {
      targetEl = document.querySelector(step.selector);
    }

    highlightElement(targetEl);

    // Compute coordinates
    let targetX = step.fallbackCoord.x;
    let targetY = step.fallbackCoord.y;

    if (targetEl) {
      const rect = targetEl.getBoundingClientRect();
      targetX = rect.left + window.scrollX + rect.width / 2;
      targetY = rect.top + window.scrollY + rect.height / 2;
    }

    cursor.style.transform = `translate(${targetX}px, ${targetY}px)`;
    document.getElementById('gitguide-cursor-pill').textContent = step.actionText;

    // Update Narration Box
    document.getElementById('gitguide-step-indicator').textContent = `Step ${currentStepIdx + 1}/${activeQuest.steps.length}`;
    document.getElementById('gitguide-box-title').textContent = activeQuest.title;
    
    const narration = activeLanguage === 'hi' ? step.narrationHi : step.narrationEn;
    document.getElementById('gitguide-box-text').textContent = narration;

    speak(narration, activeLanguage);
  }

  function nextStep() {
    currentStepIdx++;
    renderStep();
  }

  function startQuest(questId, lang) {
    if (!QUEST_DATABASE[questId]) questId = 'create-repo';
    activeQuest = QUEST_DATABASE[questId];
    currentStepIdx = 0;
    if (lang) activeLanguage = lang;
    renderStep();
  }

  function stopQuest() {
    document.querySelectorAll('.gitguide-target-highlight').forEach(e => e.classList.remove('gitguide-target-highlight'));
    const cursor = document.getElementById('gitguide-cursor');
    if (cursor) cursor.remove();
    const box = document.getElementById('gitguide-narration-box');
    if (box) box.remove();
    activeQuest = null;
  }

  // Listen for extension popup triggers
  chrome.runtime.onMessage?.addListener((msg) => {
    if (msg.action === 'START_QUEST') {
      startQuest(msg.questId, msg.lang);
    } else if (msg.action === 'STOP_QUEST') {
      stopQuest();
    }
  });

  // Keyboard shortcut Alt + G to summon
  window.addEventListener('keydown', (e) => {
    if (e.altKey && e.code === 'KeyG') {
      startQuest('create-repo', activeLanguage);
    }
  });
})();

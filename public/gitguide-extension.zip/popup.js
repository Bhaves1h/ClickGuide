// GitGuide Popup Controller
let selectedLang = 'en';

const btnLangEn = document.getElementById('btnLangEn');
const btnLangHi = document.getElementById('btnLangHi');
const questSelect = document.getElementById('questSelect');
const btnStartQuest = document.getElementById('btnStartQuest');

btnLangEn.addEventListener('click', () => {
  selectedLang = 'en';
  btnLangEn.classList.add('active');
  btnLangHi.classList.remove('active');
});

btnLangHi.addEventListener('click', () => {
  selectedLang = 'hi';
  btnLangHi.classList.add('active');
  btnLangEn.classList.remove('active');
});

btnStartQuest.addEventListener('click', async () => {
  const questId = questSelect.value;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab || !tab.url || !tab.url.includes('github.com')) {
      // If not on github.com, open github.com in a new tab
      chrome.tabs.create({ url: 'https://github.com' });
      window.close();
      return;
    }

    // Send message to active tab
    chrome.tabs.sendMessage(tab.id, {
      action: 'START_QUEST',
      questId,
      lang: selectedLang
    });

    window.close();
  } catch (err) {
    console.error('Error starting quest:', err);
    // If injection needed
    alert('Please open https://github.com and click the GitGuide icon to start.');
  }
});
